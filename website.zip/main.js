function showMsg() {
      console.log("Samikshya");
  
  }